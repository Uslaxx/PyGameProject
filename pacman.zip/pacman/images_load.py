import pygame

def pacman_images_load():
    pacman_image_1 = pygame.image.load('Pacman_anim/pacman_classic_up.png')
    pacman_image_2 = pygame.image.load('Pacman_anim/pacman_classic_left.png')
    pacman_image_3 = pygame.image.load('Pacman_anim/pacman_classic_right.png')
    pacman_image_4 = pygame.image.load('Pacman_anim/pacman_classic_down.png')
    pacman_image_start_eating_1 = pygame.image.load('Pacman_anim/pacman_classic_up_start_eating.png')
    pacman_image_start_eating_2 = pygame.image.load('Pacman_anim/pacman_classic_left_start_eating.png')
    pacman_image_start_eating_3 = pygame.image.load('Pacman_anim/pacman_classic_right_start_eating.png')
    pacman_image_start_eating_4 = pygame.image.load('Pacman_anim/pacman_classic_down_start_eating.png')
    pacman_image_middle_eating_1 = pygame.image.load('Pacman_anim/pacman_classic_up_middle_eating.png')
    pacman_image_middle_eating_2 = pygame.image.load('Pacman_anim/pacman_classic_left_middle_eating.png')
    pacman_image_middle_eating_3 = pygame.image.load('Pacman_anim/pacman_classic_right_middle_eating.png')
    pacman_image_middle_eating_4 = pygame.image.load('Pacman_anim/pacman_classic_down_middle_eating.png')
    pacman_image_eating_1 = pygame.image.load('Pacman_anim/pacman_classic_up_eating.png')
    pacman_image_eating_2 = pygame.image.load('Pacman_anim/pacman_classic_left_eating.png')
    pacman_image_eating_3 = pygame.image.load('Pacman_anim/pacman_classic_right_eating.png')
    pacman_image_eating_4 = pygame.image.load('Pacman_anim/pacman_classic_down_eating.png')
    return [pacman_image_1, pacman_image_start_eating_1, pacman_image_middle_eating_1, pacman_image_eating_1, pacman_image_middle_eating_1, pacman_image_start_eating_1,
           pacman_image_2, pacman_image_start_eating_2, pacman_image_middle_eating_2, pacman_image_eating_2, pacman_image_middle_eating_2, pacman_image_start_eating_2,
           pacman_image_3, pacman_image_start_eating_3, pacman_image_middle_eating_3, pacman_image_eating_3, pacman_image_middle_eating_3, pacman_image_start_eating_3,
           pacman_image_4, pacman_image_start_eating_4, pacman_image_middle_eating_4, pacman_image_eating_4, pacman_image_middle_eating_4, pacman_image_start_eating_4]

def angry_pacman_images_load():
    pacman_image_1 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_up.png')
    pacman_image_2 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_left.png')
    pacman_image_3 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_right.png')
    pacman_image_4 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_down.png')
    pacman_image_start_eating_1 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_up_start_eating.png')
    pacman_image_start_eating_2 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_left_start_eating.png')
    pacman_image_start_eating_3 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_right_start_eating.png')
    pacman_image_start_eating_4 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_down_start_eating.png')
    pacman_image_middle_eating_1 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_up_middle_eating.png')
    pacman_image_middle_eating_2 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_left_middle_eating.png')
    pacman_image_middle_eating_3 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_right_middle_eating.png')
    pacman_image_middle_eating_4 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_down_middle_eating.png')
    pacman_image_eating_1 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_up_eating.png')
    pacman_image_eating_2 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_left_eating.png')
    pacman_image_eating_3 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_right_eating.png')
    pacman_image_eating_4 = pygame.image.load('angry_Pacman_anim/classic_angry_pacman_down_eating.png')
    return [pacman_image_1, pacman_image_start_eating_1, pacman_image_middle_eating_1, pacman_image_eating_1, pacman_image_middle_eating_1, pacman_image_start_eating_1,
           pacman_image_2, pacman_image_start_eating_2, pacman_image_middle_eating_2, pacman_image_eating_2, pacman_image_middle_eating_2, pacman_image_start_eating_2,
           pacman_image_3, pacman_image_start_eating_3, pacman_image_middle_eating_3, pacman_image_eating_3, pacman_image_middle_eating_3, pacman_image_start_eating_3,
           pacman_image_4, pacman_image_start_eating_4, pacman_image_middle_eating_4, pacman_image_eating_4, pacman_image_middle_eating_4, pacman_image_start_eating_4]

def text_images_load():
    one = pygame.image.load('text/one.png')
    two = pygame.image.load('text/two.png')
    three = pygame.image.load('text/three.png')
    four = pygame.image.load('text/four.png')
    five = pygame.image.load('text/five.png')
    six = pygame.image.load('text/six.png')
    seven = pygame.image.load('text/seven.png')
    eight = pygame.image.load('text/eight.png')
    nine = pygame.image.load('text/nine.png')
    zero = pygame.image.load('text/zero.png')
    rec = pygame.image.load('text/record.png')
    return [zero, one, two, three, four, five, six, seven, eight, nine], rec

def death_images_load():
    death1 = pygame.image.load('Pacman_death_anim/pacman_death_1.png')
    death2 = pygame.image.load('Pacman_death_anim/pacman_death_2.png')
    death3 = pygame.image.load('Pacman_death_anim/pacman_death_3.png')
    death4 = pygame.image.load('Pacman_death_anim/pacman_death_4.png')
    death5 = pygame.image.load('Pacman_death_anim/pacman_death_5.png')
    death6 = pygame.image.load('Pacman_death_anim/pacman_death_6.png')
    death7 = pygame.image.load('Pacman_death_anim/pacman_death_7.png')
    death8 = pygame.image.load('Pacman_death_anim/pacman_death_8.png')
    death9 = pygame.image.load('Pacman_death_anim/pacman_death_9.png')
    death10 = pygame.image.load('Pacman_death_anim/pacman_death_10.png')
    death11 = pygame.image.load('Pacman_death_anim/pacman_death_11.png')
    return [death1,death2,death3,death4,death5,death6,death7,death8,death9,death10,death11]

def ghosts_image_load():
    return [pygame.image.load('pacman_env/blue_ghost.png'),pygame.image.load('pacman_env/pink_ghost.png'),pygame.image.load('pacman_env/orange_ghost.png'),pygame.image.load('pacman_env/red_ghost.png')]
