import pygame
import sys
import queue
import button
from random import randint
from highscores import HighScores
import images_load


class Settings:
    is_game_over = False
    win_width = 756

    win_height = 1036
    screen = pygame.display.set_mode((win_width, win_height))


class Level:
    def __init__(self):
        self.seeds_for_win = 0
        self.level = self.matrix_load()
        self.walls, self.seeds, self.big_seeds = self.load_objects()
        self.second_ghost_time = 72
        self.third_ghost_time = 144
        self.fourth_ghost_time = 216
        self.gm_ov = pygame.image.load('text/game_over.png').convert_alpha()
        self.gm_won = pygame.image.load('text/win.png').convert_alpha()
        self.timer = 0

    def draw_level(self, cnt, rec):
        for i in self.walls:
            i.draw()
        for i in self.seeds:
            if i.is_alive:
                i.draw()
        for i in self.big_seeds:
            if i.is_alive:
                i.draw()
        cnt.draw()
        rec.draw()

    def matrix_load(self):
        matrixes = ['Matrix', 'Matrix1']
        rand = randint(0, 1)
        level = []
        matrix = open(matrixes[rand] + '.txt')
        for line in matrix:
            level.append(list(map(int, line.split(", "))))
        matrix.close()
        return level

    def load_objects(self):
        x = 0
        y = 144
        seed = []
        wall = []
        big_seed = []
        for i in range(21):
            for j in range(21):
                if self.level[i][j] == 1:
                    wall.append(Wall(x, y))
                elif self.level[i][j] == 2:
                    seed.append(Seed(x, y))
                    self.seeds_for_win += 1
                elif self.level[i][j] == 3:
                    big_seed.append(Big_Seed(x, y))
                    self.seeds_for_win += 1
                x += 36
            y += 36
            x = 0
        return wall, seed, big_seed

    def check_collisions(self, rect):
        for i in self.walls:
            if i.check_collision(rect):
                return True
        return False

    def check_seed_collisions(self, rect, cnt, pac):
        for i in self.seeds:
            i.check_seed_collision(rect, cnt)
            if i.check_seed_collision(rect, cnt):
                self.seeds.remove(i)
                pac.seeds_eaten += 1

    def check_big_seed_collisions(self, rect, pac, cnt):
        for i in self.big_seeds:
            i.check_big_seed_collision(rect, pac, cnt)
            if i.check_big_seed_collision(rect, pac, cnt):
                self.big_seeds.remove(i)
                pac.seeds_eaten += 1


class Count:
    def __init__(self):
        self.nums, self.a = images_load.text_images_load()
        del self.a
        self.count = 10000
        self.x = 636
        self.y = 36

    def draw(self):
        Settings.screen.blit(self.nums[self.count % 10000 // 1000], [self.x - 40, self.y])
        Settings.screen.blit(self.nums[self.count % 1000 // 100], [self.x, self.y])
        Settings.screen.blit(self.nums[self.count % 100 // 10], [self.x + 40, self.y])
        Settings.screen.blit(self.nums[self.count % 10], [self.x + 80, self.y])


class Record:
    def __init__(self):
        self.record_file = open('Record.txt')
        self.nums, self.record_text = images_load.text_images_load()
        self.rec = int(self.record_file.readline())
        self.record_file.close()
        self.x = 20
        self.y = 36

    def save_record(self, cnt):
        self.record_file = open('Record.txt', 'w')
        self.record_file.write(str(cnt.count))
        self.record_file.close()

    def draw(self):
        Settings.screen.blit(self.record_text, [self.x, self.y])
        Settings.screen.blit(self.nums[self.rec % 10000 // 1000], [self.x + 260, self.y])
        Settings.screen.blit(self.nums[self.rec % 1000 // 100], [self.x + 300, self.y])
        Settings.screen.blit(self.nums[self.rec % 100 // 10], [self.x + 340, self.y])
        Settings.screen.blit(self.nums[self.rec % 10], [self.x + 380, self.y])


class Pacman:
    shifts = {'': 0, 'left': -1.5, 'up': -1.5, 'right': 1.5, 'down': 1.5}
    direction = ''
    anim_count = 0
    hp_image = pygame.image.load('pacman_env/hp.png')

    def __init__(self):
        self.x = (Settings.win_width // 2 - 18) // 36 * 36
        self.y = (Settings.win_height // 2 + 306) // 36 * 36 + 36
        self.rad = 18
        self.color = [255, 255, 0]
        self.pac_rect = pygame.Rect(self.x + 4, self.y + 4, 28, 28)
        self.is_angry = False
        self.anger_time = 0
        self.pacman_image = None
        self.pac_images = self.get_pac_images()
        self.ang_pac_images = self.get_angry_pac_images()
        self.death_images = self.get_death_images()
        self.turn_up = 0
        self.turn_left = 0
        self.turn_right = 0
        self.turn_down = 0
        self.hp = 3
        self.is_dead = False
        self.seeds_eaten = 0

    def anim_tick(self):
        Pacman.anim_count += 1
        if Pacman.anim_count == 25:
            Pacman.anim_count = 0
        self.pac_rect = pygame.Rect(self.x + 4, self.y + 4, 28, 28)

    def distances(self, level):
        dist = [[-1 for i in range(21)] for j in range(21)]
        q = queue.Queue()
        q.put([0, int(self.y // 36 - 4), int(self.x // 36)])
        while not (q.empty()):
            current = q.get()
            current_x = current[1]
            current_y = current[2]
            dist[current_x][current_y] = current[0]
            if level.level[current_x - 1][current_y] != 1 and dist[current_x - 1][current_y] == -1:
                q.put([current[0] + 1, current_x - 1, current_y])
            if level.level[current_x + 1][current_y] != 1 and dist[current_x + 1][current_y] == -1:
                q.put([current[0] + 1, current_x + 1, current_y])
            if level.level[current_x][current_y - 1] != 1 and dist[current_x][current_y - 1] == -1:
                q.put([current[0] + 1, current_x, current_y - 1])
            if level.level[current_x][current_y + 1] != 1 and dist[current_x][current_y + 1] == -1:
                q.put([current[0] + 1, current_x, current_y + 1])
        return dist

    def get_pac_images(self):
        pacman_images = images_load.pacman_images_load()
        return {'': [pacman_images[0] for i in range(6)], 'up': pacman_images[0:6], 'left': pacman_images[6:12],
                'right': pacman_images[12:18], 'down': pacman_images[18:24]}

    def get_angry_pac_images(self):
        angry_pacman_images = images_load.angry_pacman_images_load()
        return {'': [angry_pacman_images[0] for i in range(6)], 'up': angry_pacman_images[0:6],
                'left': angry_pacman_images[6:12], 'right': angry_pacman_images[12:18],
                'down': angry_pacman_images[18:24]}

    def get_death_images(self):
        return images_load.death_images_load()

    def set_direction(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_a:
            self.turn_left = 60
            self.turn_down = 0
            self.turn_up = 0
            self.turn_right = 0
        if event.type == pygame.KEYDOWN and event.key == pygame.K_d:
            self.turn_right = 60
            self.turn_down = 0
            self.turn_up = 0
            self.turn_left = 0
        if event.type == pygame.KEYDOWN and event.key == pygame.K_w:
            self.turn_up = 60
            self.turn_down = 0
            self.turn_right = 0
            self.turn_left = 0
        if event.type == pygame.KEYDOWN and event.key == pygame.K_s:
            self.turn_down = 60
            self.turn_up = 0
            self.turn_right = 0
            self.turn_left = 0

    def run(self, level):
        self.turn_down -= 1
        self.turn_left -= 1
        self.turn_right -= 1
        self.turn_up -= 1
        if self.direction == 'up' and self.turn_down > 0:
            self.turn_down = 0
            Pacman.direction = 'down'
        elif self.direction == 'down' and self.turn_up > 0:
            self.turn_down = 0
            Pacman.direction = 'up'
        elif self.direction == 'left' and self.turn_right > 0:
            self.turn_down = 0
            Pacman.direction = 'right'
        elif self.direction == 'right' and self.turn_left > 0:
            self.turn_down = 0
            Pacman.direction = 'left'
        if self.x % 36 == 0 and self.y % 36 == 0:
            if self.turn_up > 0:
                Pacman.direction = 'up'
                self.turn_up = 0
            elif self.turn_down > 0:
                Pacman.direction = 'down'
                self.turn_down = 0
            elif self.turn_left > 0:
                Pacman.direction = 'left'
                self.turn_left = 0
            elif self.turn_right > 0:
                Pacman.direction = 'right'
                self.turn_right = 0
        if Pacman.direction == 'left' and self.x + Pacman.shifts[Pacman.direction] > 0:
            if (Pacman.direction == 'left' or Pacman.direction == 'right' or self.x == 0 and self.y == 0) and (
                    (self.x % 36 != 0 and self.y % 36 != 0) or not level.check_collisions(
                pygame.Rect(self.x + Pacman.shifts[Pacman.direction], self.y, 36, 36))):
                self.x += Pacman.shifts[Pacman.direction]
            elif self.y % 36 == 0 and self.x % 36 <= 1.5:
                self.x -= self.x % 36
        elif Pacman.direction == 'right' and self.x + 36 + Pacman.shifts[Pacman.direction] < Settings.win_width:
            if (Pacman.direction == 'right' or Pacman.direction == 'left' or self.x == 0 and self.y == 0) and (
                    (self.x % 36 != 0 and self.y % 36 != 0) or not level.check_collisions(
                pygame.Rect(self.x + Pacman.shifts[Pacman.direction], self.y, 36, 36))):
                self.x += Pacman.shifts[Pacman.direction]
            elif self.y % 36 == 0 and self.x % 36 >= 34.5:
                self.x += 36 - self.x % 36
        elif Pacman.direction == 'down' and self.y + 36 + Pacman.shifts[Pacman.direction] < Settings.win_height:
            if (Pacman.direction == 'down' or Pacman.direction == 'up' or self.x == 0 and self.y == 0) and (
                    (self.x % 36 != 0 and self.y % 36 != 0) or not level.check_collisions(
                pygame.Rect(self.x, self.y + Pacman.shifts[Pacman.direction], 36, 36))):
                self.y += Pacman.shifts[Pacman.direction]
            elif self.x % 36 == 0 and self.y % 36 >= 34.5:
                self.y += 36 - self.y % 36
        elif Pacman.direction == 'up' and self.y + Pacman.shifts[Pacman.direction] > 0:
            if (Pacman.direction == 'up' or Pacman.direction == 'down' or self.x == 0 and self.y == 0) and (
                    (self.x % 36 != 0 and self.y % 36 != 0) or not level.check_collisions(
                pygame.Rect(self.x, self.y + Pacman.shifts[Pacman.direction], 36, 36))):
                self.y += Pacman.shifts[Pacman.direction]
            elif self.x % 36 == 0 and self.y % 36 <= 1.5:
                self.y -= self.y % 36

    def if_angry(self, ghosts):
        if self.is_angry and not self.is_dead:
            Pacman.shifts = {'left': -2, 'up': -2, 'right': 2, 'down': 2}
            self.anger_time += 1
            Ghost.is_scared = True
        if self.anger_time == 500 and not self.is_dead:
            ghosts_back = images_load.ghosts_image_load()
            i = 0
            self.anger_time = 0
            self.is_angry = False
            for ghost in ghosts:
                ghost.image = ghosts_back[i]
                i += 1
            Pacman.shifts = {'left': -1, 'up': -1, 'right': 1, 'down': 1}
            Ghost.is_scared = False

    def hp_check(self):
        if self.hp > 0:
            for i in range(50, self.hp * 66 + 50, 66):
                Settings.screen.blit(Pacman.hp_image, [i, 936])
        else:
            self.is_dead = True

    def win(self, lvl):
        return self.seeds_eaten == lvl.seeds_for_win

    def death_anim(self):
        for i in range(66000):
            Settings.screen.blit(self.death_images[i // 6000], [self.x, self.y])


class Ghost:
    turns = ['left', 'up', 'right', 'down']
    shifts = {'': 0, 'left': -1, 'up': -1, 'right': 1, 'down': 1}
    start_x = 360
    start_y = 432
    is_scared = False

    def __init__(self, color):
        self.dist = None
        self.previous = None
        self.x = Ghost.start_x
        self.y = Ghost.start_y
        self.direction = 'up'
        if color == 0:
            self.image = pygame.image.load('pacman_env/blue_ghost.png')
        elif color == 1:
            self.image = pygame.image.load('pacman_env/pink_ghost.png')
        elif color == 2:
            self.image = pygame.image.load('pacman_env/orange_ghost.png')
        elif color == 3:
            self.image = pygame.image.load('pacman_env/red_ghost.png')
        self.rect = pygame.Rect(self.x + 2, self.y + 2, 32, 32)

    def shuffle(self):
        Ghost.turns[0], Ghost.turns[1], Ghost.turns[2], Ghost.turns[3], = Ghost.turns[1], Ghost.turns[2], Ghost.turns[
            3], Ghost.turns[0]

    def check_pac_collision(self, pacman):
        if self.rect.colliderect(pacman.pac_rect):
            return True

    def change_direction(self, pacman, level):
        block_x = int(self.x // 36)
        block_y = int(self.y // 36 - 4)
        if level.level[block_y][block_x] == 1:
            self.x = Ghost.start_x
            self.y = Ghost.start_y

        dist = pacman.distances(level)
        for i in range(4):
            if Ghost.turns[i] == 'left' and dist[block_y][block_x] == dist[block_y][block_x - 1] + 1:
                self.direction = 'left'
                self.shuffle()
                break
            if Ghost.turns[i] == 'up' and dist[block_y][block_x] == dist[block_y - 1][block_x] + 1:
                self.direction = 'up'
                self.shuffle()
                break
            if Ghost.turns[i] == 'right' and dist[block_y][block_x] == dist[block_y][block_x + 1] + 1:
                self.direction = 'right'
                self.shuffle()
                break
            if Ghost.turns[i] == 'down' and dist[block_y][block_x] == dist[block_y + 1][block_x] + 1:
                self.direction = 'down'
                self.shuffle()
                break

    def move(self):
        if self.direction == 'left' or self.direction == 'right':
            self.x += Ghost.shifts[self.direction]
        elif self.direction == 'up' or self.direction == 'down':
            self.y += Ghost.shifts[self.direction]
        self.rect = pygame.Rect(self.x + 2, self.y + 2, 32, 32)


class Wall:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.wall_rect = pygame.Rect(self.x, self.y, 36, 36)
        self.image = pygame.image.load('pacman_env/wall.png')

    def check_collision(self, rect):
        if rect.colliderect(self.wall_rect):
            return True
        else:
            return False

    def draw(self):
        Settings.screen.blit(self.image, [self.x, self.y])


class Seed:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.seed_rect = pygame.Rect(self.x + 10, self.y + 10, 16, 16)
        self.is_alive = True
        self.image = pygame.image.load('pacman_env/seed.png')

    def check_seed_collision(self, rect, cnt):
        if rect.colliderect(self.seed_rect):
            self.is_alive = False
            cnt.count += 1
            return True

    def draw(self):
        Settings.screen.blit(self.image, [self.x, self.y])


class Big_Seed:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.big_seed_rect = pygame.Rect(self.x + 8, self.y + 8, 20, 20)
        self.is_alive = True
        self.image = pygame.image.load('pacman_env/big_seed.png')

    def check_big_seed_collision(self, rect, pac, cnt):
        if rect.colliderect(self.big_seed_rect):
            self.is_alive = False
            pac.is_angry = True
            cnt.count += 5
            pac.anger_time = 0
            return True

    def draw(self):
        Settings.screen.blit(self.image, [self.x, self.y])


Start_img = pygame.image.load("images/Start.png").convert_alpha()
Options_img = pygame.image.load("images/Options.png").convert_alpha()
Quit_img = pygame.image.load("images/Quit.png").convert_alpha()
Back_img = pygame.image.load("images/Back.png").convert_alpha()
Record_img = pygame.image.load("images/Records.png").convert_alpha()

Start_button = button.Button(250, 200, Start_img, 1)
Record_button = button.Button(250, 320, Record_img, 2)
Options_button = button.Button(250, 440, Options_img, 2)
Quit_button = button.Button(250, 560, Quit_img, 2)
Back_button = button.Button(250, 590, Back_img, 2)
Back_button_records = button.Button(250, 700, Back_img, 2)


def update_records(new_record):
    records_file = open("Record.txt")
    records = list(map(lambda x: int(x.strip()), records_file.readlines()))
    records_file.close()
    records.append(new_record)
    records.sort(reverse=True)
    records_file = open("Record.txt", mode="w")
    records_file.write("\n".join(list(map(str, records[:10]))))
    records_file.close()


def main():
    pygame.init()
    Settings.screen.fill('black')
    menu_state = "main"

    Pac = Pacman()
    Game_level = Level()
    cnt = Count()
    record = Record()
    ghosts = []
    ghosts.append(Ghost(0))
    tick = 0

    while not Settings.is_game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                if cnt.count > record.rec:
                    record.save_record(cnt)
                Settings.is_game_over = True
            Pac.set_direction(event)

        if menu_state == "main":
            Settings.screen.fill('black')
            if Start_button.draw(Settings.screen):
                menu_state = "game"
            if Record_button.draw(Settings.screen):
                menu_state = "records"
            if Options_button.draw(Settings.screen):
                menu_state = "options"
            if Quit_button.draw(Settings.screen):
                Settings.is_game_over = True
        elif menu_state == "game":
            if tick == Game_level.second_ghost_time:
                ghosts.append(Ghost(1))
            elif tick == Game_level.third_ghost_time:
                ghosts.append(Ghost(2))
            elif tick == Game_level.fourth_ghost_time:
                ghosts.append(Ghost(3))

            if not Pac.is_angry and not Pac.is_dead:
                pacman_image = Pac.pac_images[Pacman.direction][Pacman.anim_count // 5]
            elif not Pac.is_dead:
                pacman_image = Pac.ang_pac_images[Pacman.direction][Pacman.anim_count // 5]
                for ghost in ghosts:
                    ghost.image = pygame.image.load('pacman_env/ghost_scared.png')
            else:
                pacman_image = Pac.death_images[10]

            for i in ghosts:
                if i.x % 36 == 0 and i.y % 36 == 0:
                    i.change_direction(Pac, Game_level)
            for i in ghosts:
                i.move()

            Pac.run(Game_level)
            Pac.anim_tick()
            Pac.if_angry(ghosts)
            Game_level.check_seed_collisions(Pac.pac_rect, cnt, Pac)
            Game_level.check_big_seed_collisions(Pac.pac_rect, Pac, cnt)

            tick += 1

            Settings.screen.fill('black')
            Game_level.draw_level(cnt, record)
            Settings.screen.blit(pacman_image, [Pac.x, Pac.y])
            Pac.hp_check()
            for i in ghosts:
                Settings.screen.blit(i.image, [i.x, i.y])
                if i.check_pac_collision(Pac) and not Ghost.is_scared:
                    Pac.hp -= 1
                    # Pac.death_anim()
                    Pac.x, Pac.y = (Settings.win_width // 2 - 18) // 36 * 36, (
                            Settings.win_height // 2 + 306) // 36 * 36 + 36
                    ghosts = [Ghost(0)]
                    Game_level.second_ghost_time = tick + 54
                    Game_level.third_ghost_time = tick + 108
                    Game_level.fourth_ghost_time = tick + 162
                elif i.check_pac_collision(Pac) and Ghost.is_scared:
                    cnt.count += 200
                    i.x = 432
                    i.y = 360
                    i.change_direction(Pac, Game_level)

            if Pac.win(Game_level):
                Game_level.timer += 1
                Settings.screen.blit(Game_level.gm_won, [80, Settings.win_height // 2 - 50])
                Pacman.shifts = {'': 0, 'left': 0, 'up': 0, 'right': 0, 'down': 0}
                Ghost.shifts = {'': 0, 'left': 0, 'up': 0, 'right': 0, 'down': 0}
                if Game_level.timer == 200:
                    menu_state = "records"
                    new_record = cnt.count - 10000
                    update_records(new_record)
                    Game_level.timer = 0
                    Pac.seeds_eaten = 0
                    Pac.hp = 3
                    Pacman.shifts = {'': 0, 'left': -1.5, 'up': -1.5, 'right': 1.5, 'down': 1.5}
                    Ghost.shifts = {'': 0, 'left': -1, 'up': -1, 'right': 1, 'down': 1}
                    Game_level = Level()
                    cnt = Count()
                    ghosts = [Ghost(0)]
                    Game_level.second_ghost_time = tick + 54
                    Game_level.third_ghost_time = tick + 108
                    Game_level.fourth_ghost_time = tick + 162

            if Pac.is_dead:
                Game_level.timer += 1
                Settings.screen.blit(Game_level.gm_ov, [80, Settings.win_height // 2 - 50])
                Pacman.shifts = {'': 0, 'left': 0, 'up': 0, 'right': 0, 'down': 0}
                Ghost.shifts = {'': 0, 'left': 0, 'up': 0, 'right': 0, 'down': 0}
                if Game_level.timer == 200:
                    menu_state = "records"
                    new_record = cnt.count - 10000
                    update_records(new_record)
                    Game_level.timer = 0
                    Pac.is_dead = False
                    Pac.hp = 3
                    Pacman.shifts = {'': 0, 'left': -1.5, 'up': -1.5, 'right': 1.5, 'down': 1.5}
                    Ghost.shifts = {'': 0, 'left': -1, 'up': -1, 'right': 1, 'down': 1}
                    Game_level = Level()
                    cnt = Count()
                    ghosts = [Ghost(0)]
                    Game_level.second_ghost_time = tick + 54
                    Game_level.third_ghost_time = tick + 108
                    Game_level.fourth_ghost_time = tick + 162
        elif menu_state == "options":
            Settings.is_game_over = True
            print("Options :)")
        elif menu_state == "records":
            Settings.screen.fill('black')
            if Back_button_records.draw(Settings.screen):
                menu_state = "main"
            font = pygame.font.SysFont(None, 60)
            img = font.render('Records:', True, (255, 0, 0))
            Settings.screen.blit(img, (275, 100))
            records = list(map(lambda x: x.strip(), open("Record.txt").readlines()))
            for i in range(len(records)):
                font = pygame.font.SysFont(None, 50)
                img = font.render(f'{i + 1}. {records[i]}', True, (255, 0, 0))
                Settings.screen.blit(img, (275, 175 + 50 * i))
        pygame.display.flip()
        pygame.time.wait(12)
    sys.exit()


if __name__ == '__main__':
    main()
