import json


class HighScores:
    def __init__(self):
        self.scores = []
        self.load_scores()

    def load_scores(self):
        try:
            with open("highscores.txt", "r") as f:
                self.scores = json.load(f)
        except FileNotFoundError:
            pass

    def save_scores(self):
        with open("highscores.txt", "w") as f:
            json.dump(self.scores, f)

    def add_score(self, name, score):
        self.scores.append({"name": name, "score": score})
        self.scores = sorted(self.scores, key=lambda x: x["score"], reverse=True)[:10]
        self.save_scores()

    def show_scores(self):
        print("High Scores:")
        for i, score in enumerate(self.scores):
            print(f"{i+1}. {score['name']}: {score['score']}")
